/*******************************************************************************
 * Copyright 2016 Adobe Systems Incorporated
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/
package apps.we_mix.components.content.drinkslist;

import org.apache.sling.api.resource.ValueMap;

import com.adobe.cq.sightly.WCMUsePojo;
import org.apache.sling.api.resource.ResourceResolverFactory;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.Resource;
import com.day.cq.wcm.api.Page;
import com.day.cq.wcm.foundation.Image;
import com.day.cq.commons.ImageResource;
import com.day.cq.wcm.foundation.Placeholder;

public class DrinksList extends WCMUsePojo {

   	private ResourceResolver resolver;
    private String itemPath;
    private String recipeEntityPath;
    
    @Override
    public void activate() throws Exception {
        resolver = getResourceResolver();
		String listItemPath = get("itemPath", String.class);
    	itemPath = listItemPath;
    }

    public String getEntityImage(){
        getEntityPath();
        String entityImagePath = ""; 
        if (recipeEntityPath != ""){
            Resource entityResource = resolver.getResource(recipeEntityPath);
            Resource entityImage = entityResource.getChild("jcr:content").getChild("image");
            if (entityImage != null){
				ValueMap entityImageProperties = entityImage.adaptTo(ValueMap.class);
                entityImagePath = entityImageProperties.get ("fileReference","");
            }
        }

        return entityImagePath;
    }

    public String getRecipeLinkPath(){
        String itemPagePath = itemPath + ".html";
        return itemPagePath;
    }


    //use the item's path (the target page) to find the entity path from the Drink Recipe component
     private void getEntityPath() {
     	 Resource itemResource = resolver.getResource(itemPath);
         Resource recipeComponent = itemResource.getChild("jcr:content").getChild("root").getChild("responsivegrid").getChild("drinkrecipe");
         if (recipeComponent != null){
             ValueMap recipeProperties = recipeComponent.adaptTo(ValueMap.class);
             recipeEntityPath = recipeProperties.get("entityPath","");
         } else {
             recipeEntityPath = "";
         }


    }
}
